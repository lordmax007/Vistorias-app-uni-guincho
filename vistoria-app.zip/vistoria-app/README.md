# Vistoria Digital

App estático (HTML + JS) para vistoria de veículos: a retirada é registrada, o carro fica "Em Andamento" até a entrega, e a vistoria finalizada gera o PDF.

Funciona de dois jeitos:
- **Nuvem (recomendado):** as vistorias ficam salvas online, com login da equipe, e aparecem em qualquer aparelho.
- **Local:** sem configurar nada, as vistorias ficam só no navegador do aparelho.

## Fluxo
1. **Nova Retirada**: dados do veículo, cliente e local, checklist (Tem / Falta / N/A), avarias pré-existentes, fotos, observações e assinaturas do responsável e do motorista.
2. **Em Andamento**: retiradas aguardando entrega. Ao tocar em uma, registra-se o local, as fotos, a observação e a assinatura de quem recebe o carro.
3. **Finalizada**: vistorias concluídas. Daqui você baixa ou compartilha o PDF completo (retirada + entrega).

## Publicar no Vercel
1. Suba esta pasta para um repositório no GitHub e importe no Vercel (Framework: **Other**, sem build), ou rode `npx vercel --prod` dentro da pasta.
2. Pronto: o `vercel.json` já aplica os headers de segurança.

## Ligar a nuvem (Supabase, plano gratuito)
Faça uma vez só:

1. Crie uma conta em supabase.com e um **New project** (anote a senha do banco; o app não usa ela).
2. No projeto, abra **SQL Editor → New query**, cole o conteúdo de `supabase/schema.sql` e clique em **Run**. Isso cria as tabelas e a regra de segurança (só usuário logado acessa).
3. Abra **Authentication** e desligue o cadastro público (em *Sign In / Providers*, desative **Allow new users to sign up**). Sem isso, qualquer pessoa poderia criar uma conta e ver as vistorias.
4. Em **Authentication → Users → Add user**, crie o login de cada pessoa da equipe (e-mail + senha, marcando para confirmar o e-mail automaticamente).
5. Em **Project Settings → API**, copie a **Project URL** e a chave **anon / publishable**.
6. Cole as duas no `config.js` (`supabaseUrl` e `supabaseKey`) e publique de novo no Vercel.

Ao abrir o app, aparece a tela de login. Depois de entrar, todos os aparelhos enxergam as mesmas vistorias.

A chave `anon`/`publishable` pode ficar no site: ela só abre a porta de login. Quem protege os dados é o login + a regra criada pelo `schema.sql`. **Nunca** coloque no app a chave `service_role` / `secret`.

## Personalizar
- `config.js`: nome, CNPJ, telefone, endereço, logo, cor do cabeçalho do PDF e chaves da nuvem.
- `assets/logo.jpg`: troque pela logo da empresa.
- Itens do checklist: lista `ITENS` na seção de checklist de `app.js`.
- Tipos de avaria: opções do `<select id="tipoAvaria">` em `index.html`.
- Numeração: na nuvem, o número é gerado pelo banco ao salvar. Para começar de outro número, use a última linha (comentada) do `schema.sql`.

## Onde os dados ficam
- **Modo nuvem:** textos, assinaturas e fotos ficam no banco do seu projeto Supabase, e só quem tem login acessa. As fotos são reduzidas pelo app antes do envio.
- **Modo local:** ficam no IndexedDB do navegador (e se ele não existir, só na memória da aba). Nada sai do aparelho.
- A sessão de login fica guardada no aparelho até você tocar em **Sair**.
- Conexão: no modo nuvem é preciso internet para salvar e abrir vistorias. Se a conexão cair no meio de um envio, o app avisa e mantém os dados na tela para tentar de novo; nenhuma retirada fica salva pela metade.

## Segurança aplicada
- CSP restrita (só `self` e o domínio do Supabase), X-Frame-Options, HSTS, nosniff, Referrer-Policy, Permissions-Policy.
- Banco com Row Level Security: sem login, nada é lido nem gravado.
- Todo texto do usuário entra via `textContent`/`value` (sem `innerHTML`), com limite de tamanho e remoção de caracteres de controle.
- Fotos: checagem de tipo por magic bytes, limite de 30 MB e 12 fotos por etapa, recompressão no canvas (remove metadados EXIF).
- Assinaturas só são salvas depois de confirmadas.
- jsPDF empacotado localmente (`vendor/`), sem CDN externo; a nuvem é chamada direto por `fetch`, sem biblioteca de terceiros.
- Consentimento (LGPD) obrigatório antes de salvar a retirada; o texto muda conforme os dados fiquem no aparelho ou na nuvem.

## Limitações
- Todos com login enxergam e podem apagar todas as vistorias (não há perfis diferentes).
- O número da vistoria pode pular quando um envio falha e é refeito.
- O plano gratuito do Supabase tem limite de espaço (500 MB) e pode pausar o projeto depois de um período sem uso; as fotos são o que mais ocupa. Para uso contínuo, confira os limites atuais no site do Supabase.
- Sem QR code/link público de conferência.
- Vistorias que já estavam salvas só no aparelho (modo local) não são enviadas para a nuvem automaticamente.
