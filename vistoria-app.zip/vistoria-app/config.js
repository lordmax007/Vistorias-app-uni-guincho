// Dados da empresa que aparecem no cabeçalho do PDF. Edite aqui e publique de novo.
window.VISTORIA_CONFIG = {
  appName: "Vistoria Digital",          // aparece no rodapé do PDF
  empresa: "Uni-Guincho",
  cnpj: "54.165.666/0001-29",
  telefone: "(65) 99699-2472",
  endereco: "R. Cel. Gonçalo de Figueiredo, 250 - Centro Norte, Várzea Grande - MT, 78110-325",
  logo: "assets/logo.jpg",               // deixe "" para ficar sem logo
  numeroInicial: 1,                      // primeiro número de vistoria neste aparelho
  corPrincipal: [27, 107, 63],           // RGB do cabeçalho do PDF

  // Salvar na nuvem (acessar as vistorias de qualquer aparelho). Veja o passo a passo no README.
  // Deixe os dois vazios para guardar só neste aparelho.
  supabaseUrl: "",                       // ex.: "https://abcdefgh.supabase.co"
  supabaseKey: ""                        // chave "anon" / "publishable" do projeto (pode ficar no site; a segurança vem do login)
};
